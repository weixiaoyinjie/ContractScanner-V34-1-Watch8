package com.contractresearch.wear;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataEventBuffer;
import com.google.android.gms.wearable.DataMap;
import com.google.android.gms.wearable.DataMapItem;
import com.google.android.gms.wearable.Wearable;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** 44mm watch: read-only structure review and incoming phone alerts.
 * PRICE AND TIMER SETTINGS ARE EXCLUSIVELY ON THE PHONE.
 */
public final class WatchActivity extends Activity implements com.google.android.gms.wearable.DataClient.OnDataChangedListener {
    private static final int BG=Color.rgb(5,17,30),CARD=Color.rgb(14,32,53),MUTED=Color.rgb(153,174,196),
            WHITE=Color.rgb(230,242,250),GREEN=Color.rgb(69,211,157),RED=Color.rgb(242,117,141);
    private TextView title,status,price,alertInfo,chartDetail,periodHelp,oiSize,notionalDetails;
    private final TextView[] values=new TextView[8];
    private StructureChartView chart;
    private Button[] periodButtons;
    private int period=0; // 0=5m, 1=15m, 2=24h
    private boolean busy=false;
    private String symbol="";
    private WatchMetrics.Result current;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService network=Executors.newSingleThreadExecutor();
    private int sequence=0;
    private final Runnable periodic=new Runnable(){@Override public void run(){
        String incoming=WatchStore.selected(WatchActivity.this);
        if(WatchStore.validSymbol(incoming)&&!incoming.equals(symbol))setSymbol(incoming,true);
        else if(!busy&&WatchStore.validSymbol(symbol))refresh(false);
        // Watch is only a review display: phone handles the continuous market alarm.
        handler.postDelayed(this,180_000);
    }};

    @Override public void onCreate(Bundle state){
        super.onCreate(state);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        makeScreen();
        String fromNotification=getIntent().getStringExtra("symbol");
        String first=WatchStore.validSymbol(fromNotification)?fromNotification:WatchStore.selected(this);
        if(WatchStore.validSymbol(first)){
            if(WatchStore.symbols(this).contains(first))WatchStore.select(this,first);
            setSymbol(first,true);
        }else status.setText("请在手机扫描器点 ⌚ 手表 同步币种");
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},401);
        // On a fresh Wear install, Data Items may already exist; dedupe with local deletion timestamps.
        Wearable.getDataClient(this).getDataItems().addOnSuccessListener(items->{
            try{for(int i=0;i<items.getCount();i++){
                if(WatchSyncListener.PATH.equals(items.get(i).getUri().getPath())){
                    DataMap m=DataMapItem.fromDataItem(items.get(i)).getDataMap();receive(m);
                }
            }}finally{items.release();}
        });
    }
    @Override protected void onResume(){super.onResume();
        Wearable.getDataClient(this).addListener(this);
        handler.removeCallbacks(periodic);handler.postDelayed(periodic,180_000);
        String s=WatchStore.selected(this);
        if(WatchStore.validSymbol(s)&&!s.equals(symbol))setSymbol(s,true);
        updateAlert();
    }
    @Override protected void onPause(){handler.removeCallbacks(periodic);Wearable.getDataClient(this).removeListener(this);super.onPause();}
    @Override protected void onDestroy(){sequence++;network.shutdownNow();super.onDestroy();}

    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private LinearLayout vertical(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private LinearLayout horizontal(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.HORIZONTAL);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private TextView txt(String s,int sp,int color){TextView v=new TextView(this);v.setText(s);v.setTextColor(color);v.setTextSize(sp);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(WHITE);b.setAllCaps(false);b.setTextSize(11);
        b.setMinHeight(dp(35));b.setMinimumHeight(dp(35));b.setPadding(dp(2),0,dp(2),0);return b;}
    private void add(LinearLayout p,View v,int margin){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(margin);p.addView(v,lp);}
    private void makeScreen(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
        LinearLayout page=vertical();page.setPadding(dp(15),dp(12),dp(15),dp(22));scroll.addView(page);setContentView(scroll);
        title=txt("合约复查 · Wear",19,WHITE);title.setGravity(Gravity.CENTER);add(page,title,0);
        price=txt("—",20,GREEN);price.setGravity(Gravity.CENTER);add(page,price,2);
        status=txt("等待手机同步币种",10,MUTED);status.setGravity(Gravity.CENTER);add(page,status,2);
        LinearLayout nav=horizontal();
        Button previous=button("‹ 上一币"),next=button("下一币 ›"),reload=button("↻ 刷新");
        for(Button b:new Button[]{previous,next,reload})nav.addView(b,new LinearLayout.LayoutParams(0,dp(38),1));
        previous.setOnClickListener(v->shift(-1));next.setOnClickListener(v->shift(1));reload.setOnClickListener(v->refresh(true));add(page,nav,5);

        LinearLayout tabs=horizontal();periodButtons=new Button[]{button("5分钟"),button("15分钟"),button("24小时")};
        for(int i=0;i<periodButtons.length;i++){
            final int idx=i;tabs.addView(periodButtons[i],new LinearLayout.LayoutParams(0,dp(41),1));
            periodButtons[i].setOnClickListener(v->{period=idx;renderPeriod();});
        }
        add(page,tabs,6);
        periodHelp=txt("5m · 最近已收盘K线",10,MUTED);periodHelp.setGravity(Gravity.CENTER);add(page,periodHelp,2);
        String[] labels={"价格涨跌", "OI变化", "CVD净额 · USDT", "主动买占比",
                         "主动买量 · 币", "主动卖量 · 币", "总成交量 · 币", "成交额 · USDT"};
        for(int i=0;i<labels.length;i+=2){
            LinearLayout line=horizontal();
            for(int j=i;j<i+2;j++){
                LinearLayout cell=vertical();cell.setBackgroundColor(CARD);cell.setPadding(dp(7),dp(5),dp(4),dp(5));
                TextView label=txt(labels[j],10,MUTED),number=txt("—",15,WHITE);number.setSingleLine(true);
                cell.addView(label);cell.addView(number);values[j]=number;
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(57),1);
                if(j%2==1)lp.leftMargin=dp(5);line.addView(cell,lp);
            }add(page,line,4);
        }
        oiSize=txt("OI持仓规模 · —",10,MUTED);oiSize.setGravity(Gravity.CENTER);add(page,oiSize,5);
        notionalDetails=txt("主动买额/卖额 · —",10,MUTED);notionalDetails.setGravity(Gravity.CENTER);add(page,notionalDetails,2);
        chart=new StructureChartView(this);chart.setOnSelect(b->{
            if(chartDetail!=null){
                chartDetail.setText("K线 " + WatchMetrics.price(b.close)+ " · 总量 " +WatchMetrics.quantity(b.volume)
                    + "\n买量 " +WatchMetrics.quantity(b.buyBase)+" · 卖量 "+WatchMetrics.quantity(b.sellBase)
                    + "\n买额 " +WatchMetrics.usd(b.buyQuote)+" · 卖额 "+WatchMetrics.usd(b.sellQuote)
                    + "\nCVD " +WatchMetrics.signedUsd(b.cvd)+" · OI " +WatchMetrics.quantity(b.oi));
            }
        });
        LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(-1,dp(235));params.topMargin=dp(6);page.addView(chart,params);
        chartDetail=txt("触摸图表查看 K线、买量、卖量、总量、CVD、OI",10,MUTED);add(page,chartDetail,4);
        alertInfo=txt("手机端提醒 · 暂无最新消息",11,WHITE);alertInfo.setPadding(dp(7),dp(8),dp(7),dp(8));
        alertInfo.setBackgroundColor(CARD);add(page,alertInfo,9);
        Button delete=button("从手表列表删除此币");delete.setOnClickListener(v->deleteSelectedCoin());add(page,delete,8);
        TextView foot=txt("所有目标价与5/10/15分钟计时都在手机设置；手表只接收提醒。24小时买卖额/成交量来自最近288根完整5m K线；CVD是主动买额－主动卖额的累计差，不是交易所官方独立指标。",10,MUTED);
        add(page,foot,8);
    }
    private void deleteSelectedCoin(){
        if(!WatchStore.validSymbol(symbol)){toast("没有可删除的币种");return;}
        new android.app.AlertDialog.Builder(this).setTitle("删除 "+symbol.replace("USDT",""))
            .setMessage("只删除手表复查列表。手机设置的价格提醒和计时提醒继续生效。")
            .setNegativeButton("取消",(d,w)->{})
            .setPositiveButton("删除",(d,w)->{
                WatchStore.removeCoin(this,symbol);sequence++;symbol="";current=null;
                ArrayList<String> all=WatchStore.symbols(this);
                if(all.isEmpty()){
                    title.setText("合约复查 · Wear");price.setText("—");status.setText("列表为空，请从手机重新同步币种");
                    renderPeriod();updateAlert();
                }else setSymbol(all.get(0),true);
                toast("已从手表复查列表删除");
            }).show();
    }
    private void shift(int offset){ArrayList<String> all=WatchStore.symbols(this);
        if(all.isEmpty()){toast("请先从手机同步币种");return;}
        int at=all.indexOf(symbol);if(at<0)at=0;
        String next=all.get((at+offset+all.size())%all.size());WatchStore.select(this,next);setSymbol(next,true);
    }
    private void setSymbol(String next,boolean fetch){
        if(!WatchStore.validSymbol(next))return;
        if(!next.equals(symbol)){sequence++;busy=false;period=0;}
        symbol=next;current=null;title.setText(next.replace("USDT","")+" · 结构复查");price.setText("—");
        JSONObject saved=WatchStore.snapshot(this,next);
        double cur=saved.optDouble("cur",Double.NaN);
        if(Double.isFinite(cur))price.setText("快照 "+WatchMetrics.price(cur));
        long sampled=saved.optLong("sampledAt",0);
        status.setText(sampled>0?"手机快照 "+stamp(sampled)+" · 等待实时复查":"等待手表复查行情");
        renderPeriod();updateAlert();if(fetch)refresh(false);
    }
    private String stamp(long ms){return new SimpleDateFormat("HH:mm:ss",Locale.CHINA).format(new Date(ms));}
    private void renderPeriod(){
        for(int i=0;i<periodButtons.length;i++)periodButtons[i].setTextColor(i==period?GREEN:MUTED);
        periodHelp.setText(period==0?"5m · 最近一根完整5m K线":period==1?"15m · 最近一根完整15m K线":"24h · 最近288根完整5m K线");
        if(current==null){for(TextView t:values){t.setText("—");t.setTextColor(WHITE);}oiSize.setText("OI持仓规模 · —");notionalDetails.setText("主动买额/卖额 · —");
            chart.data(null);chartDetail.setText("等待实时复查图表");return;}
        WatchMetrics.Result r=current;
        WatchMetrics.Flow f=period==0?r.flow5:period==1?r.flow15:r.flow24;
        double change=period==0?r.p5:period==1?r.p15:r.p24;
        double oi=period==0?r.oi5:period==1?r.oi15:r.oi24;
        String[] displayed={WatchMetrics.percent(change),WatchMetrics.percent(oi),WatchMetrics.signedUsd(f.cvd),
            WatchMetrics.buy(f.buyPct),WatchMetrics.quantity(f.buyBase),WatchMetrics.quantity(f.sellBase),
            WatchMetrics.quantity(f.base),WatchMetrics.usd(f.total)};
        for(int i=0;i<displayed.length;i++){
            values[i].setText(displayed[i]);
            int shade=(i==0||i==1)?(i==0?change:oi)>0?GREEN:(i==0?change:oi)<0?RED:WHITE:
                i==2?f.cvd>0?GREEN:f.cvd<0?RED:WHITE:
                i==3?f.buyPct>=50?GREEN:f.buyPct<50?RED:WHITE:
                i==4?GREEN:i==5?RED:WHITE;
            values[i].setTextColor(shade);
        }
        oiSize.setText("OI持仓规模 · "+WatchMetrics.usd(r.oiUsd)+" · BTC 5m "+WatchMetrics.percent(r.btc5));
        notionalDetails.setText("买额 "+WatchMetrics.usd(f.buy)+" · 卖额 "+WatchMetrics.usd(f.sell));
        chart.data(period==0?r.five:period==1?r.fifteen:r.hourly);
    }
    private void refresh(boolean explicit){
        if(busy){if(explicit)toast("正在获取最新数据");return;}
        if(!WatchStore.validSymbol(symbol)){if(explicit)toast("先在手机同步币种");return;}
        busy=true;final String coin=symbol;final int run=++sequence;
        status.setText("正在读取已收盘K线及主动买卖额…");
        network.execute(()->{
            try{WatchMetrics.Result data=WatchMetrics.load(coin);
                runOnUiThread(()->{if(run!=sequence||!coin.equals(symbol))return;
                    busy=false;current=data;price.setText(WatchMetrics.price(data.price)+" USDT");
                    status.setText("行情 "+stamp(data.updatedAt)+(data.note.isEmpty()?"":" · "+data.note));renderPeriod();
                });
            }catch(Exception ex){runOnUiThread(()->{if(run!=sequence)return;
                busy=false;status.setText("数据未就绪："+ex.getMessage());
            });}
        });
    }
    private void updateAlert(){if(alertInfo==null)return;
        JSONObject last=WatchStore.lastEvent(this,symbol);
        if(last.length()==0)last=WatchStore.lastEvent(this,"");
        if(last.length()==0)alertInfo.setText("手机管理价格与间隔提醒 · 手表暂无通知");
        else alertInfo.setText(("price".equals(last.optString("type"))?"🔔 到价 · ":"⏱ 计时 · ")+
            last.optString("symbol").replace("USDT","")+"  "+stamp(last.optLong("at",System.currentTimeMillis()))+
            "\n"+last.optString("detail"));
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private void receive(DataMap map){
        WatchStore.receive(this,map.getString("symbol",""),map.getString("snapshot",""),map.getLong("updatedAt"));
        String choice=WatchStore.selected(this);if(WatchStore.validSymbol(choice)&&!choice.equals(symbol))setSymbol(choice,true);
    }
    @Override public void onDataChanged(DataEventBuffer events){for(DataEvent e:events){
        if(e.getType()!=DataEvent.TYPE_CHANGED)continue;
        String path=e.getDataItem().getUri().getPath();
        if(path!=null&&path.startsWith(WatchSyncListener.EVENTS)){handler.postDelayed(this::updateAlert,900);continue;}
        if(!WatchSyncListener.PATH.equals(path))continue;
        try{DataMap map=DataMapItem.fromDataItem(e.getDataItem()).getDataMap();
            runOnUiThread(()->receive(map));
        }catch(Exception ignored){}
    }}
}
