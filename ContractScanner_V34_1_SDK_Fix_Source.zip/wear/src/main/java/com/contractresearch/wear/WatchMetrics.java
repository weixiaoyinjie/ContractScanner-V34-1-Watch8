package com.contractresearch.wear;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.math.BigDecimal;

/** Public Binance USDⓈ-M futures market data. Figures are informational, not execution signals.
 * Quote volume, taker buy quote volume and base volume come from the SAME closed 5m klines.
 * All 24h flow figures cover 288 complete 5-minute bars (not the rolling 24hr ticker window).
 */
final class WatchMetrics {
    private static final String BASE="https://fapi.binance.com";
    static class Result {
        String symbol;
        double price=Double.NaN,p5=Double.NaN,p15=Double.NaN,p24=Double.NaN,
               oi5=Double.NaN,oi15=Double.NaN,oi24=Double.NaN,oiUsd=Double.NaN,btc5=Double.NaN;
        long updatedAt;
        String note="";
        Flow flow5=new Flow(),flow15=new Flow(),flow24=new Flow();
        List<Candle> five=new ArrayList<>(),fifteen=new ArrayList<>(),hourly=new ArrayList<>();
    }
    static class Candle {
        long start,end;
        double open,high,low,close;
        double volume=Double.NaN,quoteVolume=Double.NaN;
        double buyBase=Double.NaN,sellBase=Double.NaN,buyQuote=Double.NaN,sellQuote=Double.NaN;
        double oi=Double.NaN,delta=Double.NaN,cvd=Double.NaN;
        int members=1;
    }
    static class Flow {
        double buy=Double.NaN,sell=Double.NaN,total=Double.NaN,base=Double.NaN,
               buyBase=Double.NaN,sellBase=Double.NaN,cvd=Double.NaN,buyPct=Double.NaN;
        static Flow from(List<Candle> candles){
            Flow f=new Flow();if(candles==null||candles.isEmpty())return f;
            double buy=0,total=0,base=0,takerBuyBase=0;
            for(Candle c:candles){
                if(!Double.isFinite(c.buyQuote)||!Double.isFinite(c.quoteVolume)||!Double.isFinite(c.volume)||!Double.isFinite(c.buyBase))return f;
                buy+=c.buyQuote;total+=c.quoteVolume;base+=c.volume;takerBuyBase+=c.buyBase;
            }
            if(total<=0)return f;
            f.buy=buy;f.sell=total-buy;f.total=total;f.base=base;
            f.buyBase=takerBuyBase;f.sellBase=base-takerBuyBase;
            f.cvd=f.buy-f.sell;f.buyPct=f.buy/total*100;
            return f;
        }
    }
    static List<Candle> closed(JSONArray klines,long now){
        ArrayList<Candle> out=new ArrayList<>();
        for(int i=0;i<klines.length();i++){
            JSONArray a=klines.optJSONArray(i);if(a==null)continue;
            Candle c=new Candle();c.start=(long)num(a,0);c.end=(long)num(a,6);
            c.open=num(a,1);c.high=num(a,2);c.low=num(a,3);c.close=num(a,4);
            c.volume=num(a,5);c.quoteVolume=num(a,7);c.buyBase=num(a,9);c.buyQuote=num(a,10);
            if(c.end>=now||c.end<=c.start||!Double.isFinite(c.open)||!Double.isFinite(c.close)||!Double.isFinite(c.volume)||c.volume<0)continue;
            if(Double.isFinite(c.buyBase)&&c.buyBase>=0&&c.buyBase<=c.volume){c.sellBase=c.volume-c.buyBase;}
            else c.buyBase=Double.NaN;
            if(Double.isFinite(c.buyQuote)&&Double.isFinite(c.quoteVolume)&&c.buyQuote>=0&&c.quoteVolume>=0&&c.buyQuote<=c.quoteVolume){
                c.sellQuote=c.quoteVolume-c.buyQuote;c.delta=c.buyQuote-c.sellQuote;
            }else{c.buyQuote=Double.NaN;c.quoteVolume=Double.NaN;}
            out.add(c);
        }
        recalculateCvd(out);return out;
    }
    static void recalculateCvd(List<Candle> bars){double cvd=0;
        for(Candle b:bars){if(Double.isFinite(b.delta)){cvd+=b.delta;b.cvd=cvd;}else b.cvd=Double.NaN;}
    }
    /** Consecutive N*5m bars. A bucket is skipped unless ALL N bars are present and contiguous.
     * aligned=true means 15m exchange-time boundary; false makes rolling 1h blocks for the 24h view. */
    static List<Candle> aggregate(List<Candle> source,int count,boolean aligned){
        List<Candle> result=new ArrayList<>();
        if(source.size()<count)return result;
        int begin=aligned?0:Math.max(0,source.size()-288);
        if(!aligned){
            int remainder=(source.size()-begin)%count;begin+=remainder;
        }
        int i=begin;
        while(i+count<=source.size()){
            if(aligned){long span=count*300000L;
                if(source.get(i).start%span!=0){i++;continue;}
            }
            Candle aggregate=new Candle();aggregate.members=0;
            Candle first=source.get(i);aggregate.start=first.start;aggregate.open=first.open;
            aggregate.high=Double.NEGATIVE_INFINITY;aggregate.low=Double.POSITIVE_INFINITY;
            double base=0,quote=0,buyBase=0,buyQuote=0;
            boolean valid=true;
            for(int j=0;j<count;j++){
                Candle b=source.get(i+j);
                if(j>0&&b.start!=source.get(i+j-1).start+300000L){valid=false;break;}
                aggregate.high=Math.max(aggregate.high,b.high);aggregate.low=Math.min(aggregate.low,b.low);
                aggregate.close=b.close;aggregate.end=b.end;aggregate.members++;
                base+=b.volume;
                if(!Double.isFinite(b.quoteVolume)||!Double.isFinite(b.buyQuote)||!Double.isFinite(b.buyBase))valid=false;
                else{quote+=b.quoteVolume;buyBase+=b.buyBase;buyQuote+=b.buyQuote;}
            }
            if(valid&&aggregate.members==count){
                aggregate.volume=base;aggregate.quoteVolume=quote;aggregate.buyQuote=buyQuote;
                aggregate.sellQuote=quote-buyQuote;aggregate.buyBase=buyBase;aggregate.sellBase=base-buyBase;
                aggregate.delta=2*buyQuote-quote;result.add(aggregate);
            }
            i+=count;
        }
        recalculateCvd(result);return result;
    }
    static String request(String url) throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setRequestProperty("Accept","application/json");c.setConnectTimeout(6000);c.setReadTimeout(7000);c.setUseCaches(false);
        try{
            int status=c.getResponseCode();if(status!=200)throw new Exception("行情 HTTP "+status);
            StringBuilder s=new StringBuilder();
            try(InputStream stream=c.getInputStream();BufferedReader reader=new BufferedReader(new InputStreamReader(stream,StandardCharsets.UTF_8))){
                char[] buf=new char[4096];int n;while((n=reader.read(buf))>=0){s.append(buf,0,n);if(s.length()>350_000)throw new Exception("数据过大");}
            }return s.toString();
        }finally{c.disconnect();}
    }
    static double num(JSONArray k,int idx){return k.optDouble(idx,Double.NaN);}
    private static double pct(double a,double b){return Double.isFinite(a)&&Double.isFinite(b)&&b>0?(a/b-1)*100:Double.NaN;}
    private static JSONArray last(JSONArray a,int offset){return a.optJSONArray(a.length()-offset);}
    static List<Candle> lastBars(List<Candle> all,int count){
        return all.size()>=count?new ArrayList<>(all.subList(all.size()-count,all.size())):new ArrayList<>();
    }
    static Result load(String symbol) throws Exception{
        if(!WatchStore.validSymbol(symbol))throw new Exception("币种格式无效");
        ExecutorService pool=Executors.newFixedThreadPool(6);
        try{
            Future<JSONArray> k1=pool.submit(()->new JSONArray(request(BASE+"/fapi/v1/klines?symbol="+symbol+"&interval=1m&limit=19")));
            Future<JSONArray> k5=pool.submit(()->new JSONArray(request(BASE+"/fapi/v1/klines?symbol="+symbol+"&interval=5m&limit=294")));
            Future<JSONArray> oi5=pool.submit(()->new JSONArray(request(BASE+"/futures/data/openInterestHist?symbol="+symbol+"&period=5m&limit=62")));
            Future<JSONArray> oi1h=pool.submit(()->new JSONArray(request(BASE+"/futures/data/openInterestHist?symbol="+symbol+"&period=1h&limit=29")));
            Future<JSONObject> day=pool.submit(()->new JSONObject(request(BASE+"/fapi/v1/ticker/24hr?symbol="+symbol)));
            Future<JSONArray> btc=pool.submit(()->new JSONArray(request(BASE+"/fapi/v1/klines?symbol=BTCUSDT&interval=1m&limit=7")));
            JSONArray one=k1.get(),k=k5.get(),history=optional(oi5),hourHistory=optional(oi1h),btcOne=optional(btc);
            JSONObject ticker=optionalObject(day);long now=System.currentTimeMillis();
            if(one.length()<16)throw new Exception("实时价格样本不足");
            Result r=new Result();r.symbol=symbol;r.updatedAt=now;
            JSONArray current=last(one,1);
            if(current==null||num(current,6)<now-180_000)throw new Exception("实时行情已过期");
            r.price=num(current,4);r.p5=pct(r.price,num(last(one,6),4));
            r.p15=pct(r.price,num(last(one,16),4));r.p24=ticker.optDouble("priceChangePercent",Double.NaN);
            if(btcOne.length()>=6)r.btc5=pct(num(last(btcOne,1),4),num(last(btcOne,6),4));
            r.five=closed(k,now);
            if(r.five.size()<288||now-r.five.get(r.five.size()-1).end>720_000)throw new Exception("完整24小时5分钟K线不足或过期");
            r.five=lastBars(r.five,288);
            for(int i=1;i<r.five.size();i++)if(r.five.get(i).start!=r.five.get(i-1).start+300_000L)
                throw new Exception("24小时K线出现时间缺口");
            r.fifteen=aggregate(r.five,3,true);
            r.hourly=aggregate(r.five,12,false);
            r.flow5=Flow.from(lastBars(r.five,1));
            r.flow15=Flow.from(lastBars(r.fifteen,1));
            r.flow24=Flow.from(r.five);
            // If the rolling ticker is unavailable, use the same 24h CLOSED Kline window.
            if(!Double.isFinite(r.p24)){
                r.p24=pct(r.five.get(r.five.size()-1).close,r.five.get(0).open);
                r.note="24h价格使用已收盘K线";
            }
            if(!Double.isFinite(r.flow24.total))r.note="主动买卖数据缺失";
            // 5m/15m OI is timestamp-validated; missing OI must not be replaced with speculative figures.
            if(history.length()>=4){
                JSONObject currentOi=history.optJSONObject(history.length()-1);
                JSONObject prev5=history.optJSONObject(history.length()-2);
                JSONObject prev15=history.optJSONObject(history.length()-4);
                if(currentOi!=null&&prev5!=null&&prev15!=null){
                    long t=currentOi.optLong("timestamp",0);
                    if(t>0&&now-t<=720000&&Math.abs(t-prev5.optLong("timestamp")-300000)<=2000&&Math.abs(t-prev15.optLong("timestamp")-900000)<=3000){
                        double v=currentOi.optDouble("sumOpenInterest",Double.NaN);
                        r.oi5=pct(v,prev5.optDouble("sumOpenInterest",Double.NaN));
                        r.oi15=pct(v,prev15.optDouble("sumOpenInterest",Double.NaN));
                        r.oiUsd=currentOi.optDouble("sumOpenInterestValue",Double.NaN);
                    }
                }
                // OI 5m snapshots only apply to last few hours of charts.
                for(Candle bar:r.five){long best=Long.MAX_VALUE;
                    for(int j=0;j<history.length();j++){
                        JSONObject v=history.optJSONObject(j);if(v==null)continue;
                        long dist=Math.abs(v.optLong("timestamp",0)-bar.end);
                        if(dist<best){best=dist;bar.oi=v.optDouble("sumOpenInterest",Double.NaN);}
                    }
                    if(best>165000)bar.oi=Double.NaN;
                }
                for(Candle bar:r.fifteen){long best=Long.MAX_VALUE;
                    for(int j=0;j<history.length();j++){
                        JSONObject v=history.optJSONObject(j);if(v==null)continue;
                        long dist=Math.abs(v.optLong("timestamp",0)-bar.end);
                        if(dist<best){best=dist;bar.oi=v.optDouble("sumOpenInterest",Double.NaN);}
                    }
                    if(best>360000)bar.oi=Double.NaN;
                }
            }
            // 24h OI uses 1h OI snapshots; 24h change only shown when endpoints are precisely 24h apart.
            if(hourHistory.length()>=25){
                JSONObject cur=hourHistory.optJSONObject(hourHistory.length()-1);
                JSONObject old=hourHistory.optJSONObject(hourHistory.length()-25);
                if(cur!=null&&old!=null&&now-cur.optLong("timestamp",0)<=10_800_000&&
                    Math.abs(cur.optLong("timestamp",0)-old.optLong("timestamp",0)-86_400_000)<120000){
                    r.oi24=pct(cur.optDouble("sumOpenInterest",Double.NaN),old.optDouble("sumOpenInterest",Double.NaN));
                }
                for(Candle bar:r.hourly){long best=Long.MAX_VALUE;
                    for(int j=0;j<hourHistory.length();j++){
                        JSONObject v=hourHistory.optJSONObject(j);if(v==null)continue;
                        long dist=Math.abs(v.optLong("timestamp",0)-bar.end);
                        if(dist<best){best=dist;bar.oi=v.optDouble("sumOpenInterest",Double.NaN);}
                    }
                    if(best>2_100_000)bar.oi=Double.NaN;
                }
            }
            if(!Double.isFinite(r.price)||r.price<=0||!Double.isFinite(r.p5)||!Double.isFinite(r.p15))throw new Exception("价格字段无效");
            return r;
        }finally{pool.shutdownNow();}
    }
    private static JSONArray optional(Future<JSONArray> f){try{return f.get();}catch(Exception ex){return new JSONArray();}}
    private static JSONObject optionalObject(Future<JSONObject> f){try{return f.get();}catch(Exception ex){return new JSONObject();}}
    static String price(double x){
        if(!Double.isFinite(x))return "—";
        if(x>=100)return String.format(Locale.US,"%.2f",x);
        if(x>=1)return String.format(Locale.US,"%.4f",x);
        if(x>=.01)return String.format(Locale.US,"%.5f",x);
        if(x>=.0001)return String.format(Locale.US,"%.7f",x);
        return BigDecimal.valueOf(x).stripTrailingZeros().toPlainString();
    }
    static String percent(double x){return Double.isFinite(x)?String.format(Locale.US,"%+.2f%%",x):"—";}
    static String buy(double x){return Double.isFinite(x)?String.format(Locale.US,"%.1f%%",x):"—";}
    private static String compact(double x){
        double n=Math.abs(x);
        if(n>=1e9)return String.format(Locale.US,"%.2fB",n/1e9);
        if(n>=1e6)return String.format(Locale.US,"%.2fM",n/1e6);
        if(n>=1e3)return String.format(Locale.US,"%.1fK",n/1e3);
        return String.format(Locale.US,n<1?"%.3f":"%.2f",n);
    }
    static String usd(double x){return Double.isFinite(x)?(x<0?"-":"")+"$"+compact(x):"—";}
    static String signedUsd(double x){return Double.isFinite(x)?(x>0?"+":x<0?"-":"")+"$"+compact(x):"—";}
    static String quantity(double x){return Double.isFinite(x)?(x<0?"-":"")+compact(x):"—";}
}
