package com.contractresearch.wear;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** Wear-local persistence. Data Layer is a transport, not a durable watch database. */
final class WatchStore {
    private static SharedPreferences prefs(Context c){return c.getSharedPreferences("scanner_wear_v1",Context.MODE_PRIVATE);}
    static boolean validSymbol(String s){return s!=null&&s.matches("[A-Z0-9]{2,24}USDT");}
    static synchronized void receive(Context c,String symbol,String snapshot,long updatedAt){
        if(!validSymbol(symbol)||snapshot==null||snapshot.length()>2500||updatedAt<=prefs(c).getLong("deleted_"+symbol,0))return;
        try{if(!symbol.equals(new JSONObject(snapshot).optString("symbol")))return;}catch(Exception e){return;}
        if(updatedAt<prefs(c).getLong("syncAt_"+symbol,0))return;
        ArrayList<String> all=symbols(c);all.remove(symbol);all.add(0,symbol);
        while(all.size()>12)all.remove(all.size()-1);
        JSONArray array=new JSONArray();for(String s:all)array.put(s);
        prefs(c).edit().putString("coins",array.toString()).putString("selected",symbol)
                .putString("snapshot_"+symbol,snapshot).putLong("syncAt_"+symbol,updatedAt).apply();
    }
    static synchronized ArrayList<String> symbols(Context c){
        ArrayList<String> out=new ArrayList<>();
        try{JSONArray j=new JSONArray(prefs(c).getString("coins","[]"));for(int i=0;i<j.length();i++){
            String s=j.optString(i,"");if(validSymbol(s)&&!out.contains(s))out.add(s);
        }}catch(Exception ignored){}return out;
    }
    static String selected(Context c){return prefs(c).getString("selected","");}
    static void select(Context c,String s){if(validSymbol(s))prefs(c).edit().putString("selected",s).apply();}
    static JSONObject snapshot(Context c,String s){try{return new JSONObject(prefs(c).getString("snapshot_"+s,"{}"));}catch(Exception e){return new JSONObject();}}
    static long syncAt(Context c,String s){return prefs(c).getLong("syncAt_"+s,0);}

    static synchronized void removeCoin(Context c,String s){
        if(!validSymbol(s))return;
        ArrayList<String> all=symbols(c);all.remove(s);JSONArray arr=new JSONArray();for(String v:all)arr.put(v);
        SharedPreferences pref=prefs(c);
        pref.edit().putString("coins",arr.toString())
            .putLong("deleted_"+s,Math.max(System.currentTimeMillis(),pref.getLong("syncAt_"+s,0)))
            .remove("snapshot_"+s).remove("syncAt_"+s)
            .putString("selected",all.isEmpty()?"":all.get(0)).apply();
    }
    /** Returns true only for an unseen event; safe against Data Layer replay. */
    static synchronized boolean addEvent(Context c,String id,String symbol,String type,String detail,long at){
        if(id==null||!id.matches("[A-Za-z0-9_-]{8,95}")||!validSymbol(symbol)||
            !("price".equals(type)||"timer".equals(type))||detail==null||detail.length()>350||at<=0)return false;
        try{
            JSONArray old=new JSONArray(prefs(c).getString("events","[]"));
            for(int i=0;i<old.length();i++)if(id.equals(old.optJSONObject(i).optString("id")))return false;
            JSONObject item=new JSONObject().put("id",id).put("symbol",symbol).put("type",type).put("detail",detail).put("at",at);
            JSONArray recent=new JSONArray();recent.put(item);
            for(int i=0;i<old.length()&&recent.length()<25;i++)recent.put(old.get(i));
            prefs(c).edit().putString("events",recent.toString()).apply();return true;
        }catch(Exception e){return false;}
    }
    static JSONObject lastEvent(Context c,String symbol){
        try{JSONArray arr=new JSONArray(prefs(c).getString("events","[]"));
            for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i);
                if(o!=null&&(symbol==null||symbol.isEmpty()||symbol.equals(o.optString("symbol"))))return o;}
        }catch(Exception ignored){}return new JSONObject();
    }
}
