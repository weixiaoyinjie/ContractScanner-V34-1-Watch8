package com.contractresearch.wear;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataEventBuffer;
import com.google.android.gms.wearable.DataMap;
import com.google.android.gms.wearable.DataMapItem;
import com.google.android.gms.wearable.WearableListenerService;

/** Wear receives selections and phone-generated alert events; no watch-side alert settings. */
public final class WatchSyncListener extends WearableListenerService {
    static final String PATH="/scanner/watch/selected", EVENTS="/scanner/watch/events/", CHANNEL="scanner_wear_phone_alerts";
    @Override public void onDataChanged(DataEventBuffer events){
        for(DataEvent e:events){
            if(e.getType()!=DataEvent.TYPE_CHANGED)continue;
            try{
                String path=e.getDataItem().getUri().getPath();
                if(path==null)continue;
                DataMap m=DataMapItem.fromDataItem(e.getDataItem()).getDataMap();
                if(PATH.equals(path)){
                    WatchStore.receive(this,m.getString("symbol",""),m.getString("snapshot",""),m.getLong("updatedAt"));
                }else if(path.startsWith(EVENTS)){
                    String id=path.substring(EVENTS.length());String symbol=m.getString("symbol","");
                    String kind=m.getString("type","");String detail=m.getString("detail","");long at=m.getLong("at",0);
                    if(WatchStore.addEvent(this,id,symbol,kind,detail,at))notifyWatch(id,symbol,kind,detail,at);
                }
            }catch(Exception ignored){}
        }
    }
    private void notifyWatch(String id,String symbol,String kind,String detail,long at){
        // Don't vibrate on old notifications replayed after a long offline period.
        if(Math.abs(System.currentTimeMillis()-at)>15*60_000L)return;
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        NotificationManager nm=getSystemService(NotificationManager.class);
        NotificationChannel c=new NotificationChannel(CHANNEL,"手机到价与计时通知",NotificationManager.IMPORTANCE_HIGH);
        c.enableVibration(true);nm.createNotificationChannel(c);
        Intent target=new Intent(this,WatchActivity.class).putExtra("symbol",symbol).putExtra("eventId",id);
        PendingIntent pi=PendingIntent.getActivity(this,Math.abs(id.hashCode()),target,
            PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        String title=symbol.replace("USDT","")+("price".equals(kind)?" · 触达目标价格":" · 定时复查");
        String note="price".equals(kind)?detail:("手机计时已到 · "+detail);
        Notification n=new Notification.Builder(this,CHANNEL).setSmallIcon(R.drawable.ic_watch)
            .setContentTitle(title).setContentText(note).setStyle(new Notification.BigTextStyle().bigText(note))
            .setCategory(Notification.CATEGORY_REMINDER).setPriority(Notification.PRIORITY_HIGH).setAutoCancel(true)
            .setContentIntent(pi).build();
        nm.notify(Math.abs(id.hashCode()),n);
    }
}
