package com.contractresearch.flowplusminute;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import com.google.android.gms.wearable.PutDataMapRequest;
import com.google.android.gms.wearable.PutDataRequest;
import com.google.android.gms.wearable.Wearable;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicLong;

/** Android native phone-based market & timer service; independent clocks and toggles.
 * Price samples are best-effort HTTP observations, not a guaranteed exchange tick feed. */
public final class PhoneAlertService extends Service {
    private static final String RUNNING="scanner_v34_monitor", EVENTS="scanner_v34_alerts";
    private static final int ONGOING_ID=62001;
    private static final long PRICE_INTERVAL=30_000;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final AtomicLong eventSequence=new AtomicLong();
    private long nextPriceAt=0;
    private boolean checking=false;
    private final Runnable cycle=this::tick;
    @Override public IBinder onBind(Intent intent){return null;}
    @Override public void onCreate(){super.onCreate();
        NotificationManager nm=getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(RUNNING,"合约价格及定时监测",NotificationManager.IMPORTANCE_LOW));
        NotificationChannel high=new NotificationChannel(EVENTS,"合约到价/计时提醒",NotificationManager.IMPORTANCE_HIGH);
        high.enableVibration(true);nm.createNotificationChannel(high);
    }
    private Notification ongoing(){
        int n=AlertStore.active(this).size();
        PendingIntent pi=PendingIntent.getActivity(this,8,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this,RUNNING).setSmallIcon(R.drawable.ic_scanner)
                .setContentTitle("合约提醒运行中").setContentText("手机监测 "+n+" 币 · 到价/定时独立")
                .setContentIntent(pi).setOngoing(true).setLocalOnly(true).build();
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        try{
            Notification n=ongoing();
            if(Build.VERSION.SDK_INT>=34)startForeground(ONGOING_ID,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else startForeground(ONGOING_ID,n);
        }catch(Exception e){stopSelf();return START_NOT_STICKY;}
        handler.removeCallbacks(cycle);handler.post(cycle);
        return START_STICKY;
    }
    private void tick(){
        List<AlertStore.Rule> rules=AlertStore.active(this);
        if(rules.isEmpty()){stopSelf();return;}
        long now=System.currentTimeMillis();
        // Independent PHONE clock: never wait for slow Binance requests to finish.
        // These alarms still depend on Android actually scheduling this service.
        for(AlertStore.Rule r:rules){
            if(r.timerEnabled&&now>=r.nextAt&&AlertStore.timerDue(this,r,now))
                signal(r.symbol,"timer","每隔 "+r.minutes+" 分钟提醒 · "+(r.repeat?"循环":"一次"),Double.NaN,0);
        }
        if(!checking&&now>=nextPriceAt){
            checking=true;nextPriceAt=now+PRICE_INTERVAL;
            worker.execute(()->{
                // Price checks run separately: changing a target doesn't alter the timer schedule.
                for(AlertStore.Rule r:rules){
                    if(!r.priceEnabled)continue;
                    AlertStore.Rule live=AlertStore.get(this,r.symbol);
                    if(!live.priceEnabled||live.target!=r.target||live.above!=r.above)continue;
                    try{
                        double sampled=price(r.symbol);
                        if((r.above?sampled>=r.target:sampled<=r.target)&&AlertStore.priceHit(this,r)){
                            signal(r.symbol,"price","目标 "+(r.above?"≥":"≤")+" "+format(r.target)+" · 触发采样价 "+format(sampled),sampled,r.target);
                        }
                    }catch(Exception ignored){/* Network faults must never create synthetic price hits. */}
                }
                handler.post(()->{
                    checking=false;
                    getSystemService(NotificationManager.class).notify(ONGOING_ID,ongoing());
                });
            });
        }
        handler.postDelayed(cycle,1000);
    }
    private static String format(double value){return java.math.BigDecimal.valueOf(value).stripTrailingZeros().toPlainString();}
    private static double price(String symbol) throws Exception {
        if(!AlertStore.validSymbol(symbol))throw new Exception("非法币种");
        HttpURLConnection c=(HttpURLConnection)new URL("https://fapi.binance.com/fapi/v1/ticker/price?symbol="+symbol).openConnection();
        c.setConnectTimeout(6000);c.setReadTimeout(6000);c.setUseCaches(false);
        try{
            if(c.getResponseCode()!=200)throw new Exception("行情接口暂不可用");
            StringBuilder s=new StringBuilder();
            try(BufferedReader in=new BufferedReader(new InputStreamReader(c.getInputStream(),StandardCharsets.UTF_8))){
                char[] b=new char[1024];int n;while((n=in.read(b))>0){s.append(b,0,n);if(s.length()>5000)throw new Exception("响应过大");}}
            double result=new JSONObject(s.toString()).optDouble("price",Double.NaN);
            if(!Double.isFinite(result)||result<=0)throw new Exception("无效价格");return result;
        }finally{c.disconnect();}
    }
    private void signal(String symbol,String type,String detail,double observed,double target){
        long now=System.currentTimeMillis();String base=symbol.replace("USDT","");
        String title=base+("price".equals(type)?" 已达到目标价格":" 定时复查提醒");
        if(Build.VERSION.SDK_INT<33||checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED){
            Intent open=new Intent(this,MainActivity.class);
            PendingIntent pi=PendingIntent.getActivity(this,7,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
            Notification note=new Notification.Builder(this,EVENTS).setSmallIcon(R.drawable.ic_scanner)
                    .setContentTitle(title).setContentText(detail).setStyle(new Notification.BigTextStyle().bigText(detail))
                    .setContentIntent(pi).setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_HIGH)
                    .setAutoCancel(true).setLocalOnly(true).build();
            getSystemService(NotificationManager.class).notify((int)(now%1000000)+("price".equals(type)?1:2),note);
        }
        // Durable Data Layer event: phone notifications are local-only to avoid duplicate mirroring.
        try{
            String id=now+"-"+symbol+"-"+type+"-"+eventSequence.incrementAndGet();
            PutDataMapRequest request=PutDataMapRequest.create("/scanner/watch/events/"+id);
            request.getDataMap().putString("symbol",symbol);
            request.getDataMap().putString("type",type);
            request.getDataMap().putString("detail",detail);
            request.getDataMap().putString("title",title);
            request.getDataMap().putLong("at",now);
            request.getDataMap().putDouble("observed",observed);
            request.getDataMap().putDouble("target",target);
            PutDataRequest data=request.asPutDataRequest();data.setUrgent();
            Wearable.getDataClient(this).putDataItem(data);
            // Cap queued events to 40 to avoid an unbounded Data Layer backlog.
            Wearable.getDataClient(this).getDataItems().addOnSuccessListener(items->{
                try{
                    java.util.ArrayList<android.net.Uri> paths=new java.util.ArrayList<>();
                    for(int i=0;i<items.getCount();i++){
                        android.net.Uri uri=items.get(i).getUri();
                        if(uri.getPath()!=null&&uri.getPath().startsWith("/scanner/watch/events/"))paths.add(uri);
                    }
                    paths.sort((a,b)->a.getPath().compareTo(b.getPath()));
                    for(int i=0;i<paths.size()-40;i++)Wearable.getDataClient(this).deleteDataItems(paths.get(i));
                }finally{items.release();}
            });
        }catch(Exception ignored){}
    }
    @Override public void onDestroy(){handler.removeCallbacks(cycle);worker.shutdownNow();super.onDestroy();}
    @Override public void onTimeout(int startId,int fgsType){stopSelf();}
}
