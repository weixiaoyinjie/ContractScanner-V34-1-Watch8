package com.contractresearch.flowplusminute;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Independent price and clock alarms, persisted on the PHONE only. */
final class AlertStore {
    private static final String NAME="scanner_phone_alerts_v34";
    private static final int MAX_SYMBOLS=12;
    static boolean validSymbol(String s){return s!=null&&s.matches("[A-Z0-9]{2,24}USDT");}
    static class Rule {
        final String symbol;
        boolean priceEnabled,above=true,timerEnabled,repeat=true;
        double target;
        int minutes=5;
        long nextAt;
        Rule(String s){symbol=s;}
        boolean active(){return priceEnabled||timerEnabled;}
        JSONObject toJson(){try{return new JSONObject().put("priceEnabled",priceEnabled).put("above",above)
                .put("target",target).put("timerEnabled",timerEnabled).put("minutes",minutes)
                .put("repeat",repeat).put("nextAt",nextAt);}catch(Exception e){return new JSONObject();}}
        static Rule parse(String symbol,JSONObject o){Rule r=new Rule(symbol);
            r.priceEnabled=o.optBoolean("priceEnabled",false);
            r.target=o.optDouble("target",0);
            r.above=o.optBoolean("above",true);
            r.timerEnabled=o.optBoolean("timerEnabled",false);
            r.minutes=o.optInt("minutes",5);if(r.minutes!=5&&r.minutes!=10&&r.minutes!=15)r.minutes=5;
            r.repeat=o.optBoolean("repeat",true);r.nextAt=o.optLong("nextAt",0);
            if(!Double.isFinite(r.target)||r.target<=0||r.target>1e12)r.priceEnabled=false;
            return r;
        }
    }
    private static SharedPreferences prefs(Context ctx){return ctx.getSharedPreferences(NAME,Context.MODE_PRIVATE);}
    private static JSONObject all(Context ctx){try{return new JSONObject(prefs(ctx).getString("rules","{}"));}catch(Exception e){return new JSONObject();}}
    private static void write(Context c,JSONObject o){prefs(c).edit().putString("rules",o.toString()).commit();}
    static synchronized Rule get(Context c,String symbol){if(!validSymbol(symbol))return new Rule("");return Rule.parse(symbol,all(c).optJSONObject(symbol)==null?new JSONObject():all(c).optJSONObject(symbol));}
    static synchronized List<Rule> active(Context c){ArrayList<Rule> list=new ArrayList<>();JSONObject a=all(c);
        for(Iterator<String> it=a.keys();it.hasNext();){String s=it.next();if(validSymbol(s)){
            JSONObject v=a.optJSONObject(s);if(v!=null){Rule r=Rule.parse(s,v);if(r.active())list.add(r);}
        }}return list;
    }
    static synchronized String saveSettings(Context c,String symbol,String raw) {
        if(!validSymbol(symbol))return "币种格式无效";
        try{
            if(raw==null||raw.length()>1100)return "设置数据过长";
            JSONObject v=new JSONObject(raw);
            boolean pe=v.getBoolean("priceEnabled"),te=v.getBoolean("timerEnabled");
            double target=v.optDouble("target",0);boolean above=v.getBoolean("above");
            int minutes=v.getInt("minutes");boolean repeat=v.getBoolean("repeat");
            if(pe&&(!Double.isFinite(target)||target<=0||target>1e12))return "请输入大于0的有效目标价格";
            if(minutes!=5&&minutes!=10&&minutes!=15)return "定时间隔只支持5、10或15分钟";
            JSONObject a=all(c);
            if(!a.has(symbol)&&a.length()>=MAX_SYMBOLS&&(pe||te))return "最多同时保存12个币种的提醒设置";
            Rule old=Rule.parse(symbol,a.optJSONObject(symbol)==null?new JSONObject():a.optJSONObject(symbol));
            Rule r=new Rule(symbol);r.priceEnabled=pe;r.above=above;r.target=target;
            r.timerEnabled=te;r.minutes=minutes;r.repeat=repeat;
            // Changing the price target must not restart an unchanged timer.
            r.nextAt=te&&old.timerEnabled&&old.minutes==minutes&&old.repeat==repeat&&old.nextAt>0
                    ?old.nextAt:(te?System.currentTimeMillis()+minutes*60_000L:0);
            if(r.active())a.put(symbol,r.toJson());else a.remove(symbol);
            write(c,a);return "OK";
        }catch(Exception e){return "设置内容不正确";}
    }
    static synchronized boolean priceHit(Context c,Rule snapshot){
        JSONObject a=all(c);JSONObject v=a.optJSONObject(snapshot.symbol);
        if(v==null)return false;Rule live=Rule.parse(snapshot.symbol,v);
        if(!live.priceEnabled||live.target!=snapshot.target||live.above!=snapshot.above)return false;
        live.priceEnabled=false;if(live.active())a.put(snapshot.symbol,live.toJson());else a.remove(snapshot.symbol);
        write(c,a);return true;
    }
    /** Advance each due timer from previous scheduled time: no drift, no missed-event backlog. */
    static synchronized boolean timerDue(Context c,Rule snapshot,long now){
        JSONObject a=all(c),v=a.optJSONObject(snapshot.symbol);if(v==null)return false;
        Rule live=Rule.parse(snapshot.symbol,v);
        if(!live.timerEnabled||live.minutes!=snapshot.minutes||live.repeat!=snapshot.repeat||live.nextAt!=snapshot.nextAt||now<live.nextAt)return false;
        if(live.repeat){long step=live.minutes*60_000L;live.nextAt+=((now-live.nextAt)/step+1)*step;}
        else{live.timerEnabled=false;live.nextAt=0;}
        if(live.active())a.put(live.symbol,live.toJson());else a.remove(live.symbol);
        write(c,a);return true;
    }
}
